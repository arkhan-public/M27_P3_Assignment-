using Microsoft.AspNetCore.Mvc.RazorPages;

namespace QAWebApp.Pages;

public class LoginModel : PageModel
{
    public void OnGet()
    {
    }
}
