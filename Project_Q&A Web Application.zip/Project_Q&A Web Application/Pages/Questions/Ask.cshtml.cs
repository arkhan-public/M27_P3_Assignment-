using Microsoft.AspNetCore.Mvc.RazorPages;

namespace QAWebApp.Pages.Questions;

public class AskModel : PageModel
{
    public void OnGet()
    {
    }
}
