using Microsoft.AspNetCore.Mvc.RazorPages;

namespace QAWebApp.Pages;

public class RegisterModel : PageModel
{
    public void OnGet()
    {
    }
}
