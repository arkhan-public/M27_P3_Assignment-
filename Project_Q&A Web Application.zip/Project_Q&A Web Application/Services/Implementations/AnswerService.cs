using QAWebApp.DTOs;
using QAWebApp.Models;
using QAWebApp.Repositories.Interfaces;
using QAWebApp.Services.Interfaces;

namespace QAWebApp.Services.Implementations;

public class AnswerService : IAnswerService
{
    private readonly IAnswerRepository _answerRepository;
    private readonly IQuestionRepository _questionRepository;
    private readonly ICommentRepository _commentRepository;
    private readonly IVoteRepository _voteRepository;
    private readonly ILogger<AnswerService> _logger;

    public AnswerService(
        IAnswerRepository answerRepository,
        IQuestionRepository questionRepository,
        ICommentRepository commentRepository,
        IVoteRepository voteRepository,
        ILogger<AnswerService> logger)
    {
        _answerRepository = answerRepository;
        _questionRepository = questionRepository;
        _commentRepository = commentRepository;
        _voteRepository = voteRepository;
        _logger = logger;
    }

    public async Task<(bool Success, string Message, Answer? Answer)> CreateAnswerAsync(AnswerCreateDto dto, int userId)
    {
        try
        {
            var question = await _questionRepository.GetByIdAsync(dto.QuestionId);
            if (question == null)
            {
                return (false, "Question not found", null);
            }

            var answer = new Answer
            {
                Body = dto.Body,
                QuestionId = dto.QuestionId,
                UserId = userId,
                CreatedAt = DateTime.UtcNow
            };

            await _answerRepository.AddAsync(answer);
            await _answerRepository.SaveChangesAsync();

            _logger.LogInformation("Answer {AnswerId} created for question {QuestionId} by user {UserId}",
                answer.Id, dto.QuestionId, userId);
            return (true, "Answer posted successfully", answer);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating answer for question {QuestionId}", dto.QuestionId);
            return (false, "An error occurred while posting the answer", null);
        }
    }

    public async Task<(bool Success, string Message)> UpdateAnswerAsync(int answerId, AnswerUpdateDto dto, int userId)
    {
        try
        {
            var answer = await _answerRepository.GetByIdAsync(answerId);

            if (answer == null)
            {
                return (false, "Answer not found");
            }

            if (answer.UserId != userId)
            {
                _logger.LogWarning("User {UserId} attempted to update answer {AnswerId} owned by user {OwnerId}",
                    userId, answerId, answer.UserId);
                return (false, "You do not have permission to update this answer");
            }

            answer.Body = dto.Body;
            answer.UpdatedAt = DateTime.UtcNow;

            _answerRepository.Update(answer);
            await _answerRepository.SaveChangesAsync();

            _logger.LogInformation("Answer {AnswerId} updated by user {UserId}", answerId, userId);
            return (true, "Answer updated successfully");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating answer {AnswerId}", answerId);
            return (false, "An error occurred while updating the answer");
        }
    }

    public async Task<(bool Success, string Message)> DeleteAnswerAsync(int answerId, int userId)
    {
        try
        {
            var answer = await _answerRepository.GetAnswerWithDetailsAsync(answerId);

            if (answer == null)
            {
                return (false, "Answer not found");
            }

            if (answer.UserId != userId)
            {
                _logger.LogWarning("User {UserId} attempted to delete answer {AnswerId} owned by user {OwnerId}",
                    userId, answerId, answer.UserId);
                return (false, "You do not have permission to delete this answer");
            }

            // Delete all comments on the answer
            var comments = await _commentRepository.GetCommentsByAnswerIdAsync(answerId);
            if (comments.Any())
            {
                _commentRepository.RemoveRange(comments);
                await _commentRepository.SaveChangesAsync();
                _logger.LogInformation("Deleting {Count} comments from answer {AnswerId}", 
                    comments.Count, answerId);
            }

            // Delete all votes on the answer
            var votes = await _voteRepository.GetVotesByAnswerIdAsync(answerId);
            if (votes.Any())
            {
                _voteRepository.RemoveRange(votes);
                await _voteRepository.SaveChangesAsync();
                _logger.LogInformation("Deleting {Count} votes from answer {AnswerId}", 
                    votes.Count, answerId);
            }

            // Finally, delete the answer
            _answerRepository.Remove(answer);
            await _answerRepository.SaveChangesAsync();

            _logger.LogInformation("Answer {AnswerId} and all related data deleted successfully by user {UserId}", 
                answerId, userId);
            return (true, "Answer and all related content deleted successfully");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting answer {AnswerId}", answerId);
            return (false, "An error occurred while deleting the answer");
        }
    }

    public async Task<(bool Success, string Message)> AcceptAnswerAsync(int answerId, int userId)
    {
        try
        {
            var answer = await _answerRepository.GetAnswerWithDetailsAsync(answerId);

            if (answer == null)
            {
                return (false, "Answer not found");
            }

            if (answer.Question.UserId != userId)
            {
                _logger.LogWarning("User {UserId} attempted to accept answer {AnswerId} for question owned by user {OwnerId}",
                    userId, answerId, answer.Question.UserId);
                return (false, "Only the question owner can accept answers");
            }

            // Unaccept any previously accepted answer
            var previouslyAccepted = await _answerRepository.GetAcceptedAnswerByQuestionIdAsync(answer.QuestionId);
            if (previouslyAccepted != null && previouslyAccepted.Id != answerId)
            {
                previouslyAccepted.IsAccepted = false;
                _answerRepository.Update(previouslyAccepted);
            }

            answer.IsAccepted = true;
            _answerRepository.Update(answer);
            await _answerRepository.SaveChangesAsync();

            _logger.LogInformation("Answer {AnswerId} accepted for question {QuestionId}", answerId, answer.QuestionId);
            return (true, "Answer accepted successfully");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error accepting answer {AnswerId}", answerId);
            return (false, "An error occurred while accepting the answer");
        }
    }

    public async Task<Answer?> GetAnswerByIdAsync(int answerId)
    {
        try
        {
            return await _answerRepository.GetAnswerWithDetailsAsync(answerId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving answer {AnswerId}", answerId);
            return null;
        }
    }

    public async Task<List<Answer>> GetAnswersByQuestionIdAsync(int questionId)
    {
        try
        {
            return await _answerRepository.GetAnswersByQuestionIdAsync(questionId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving answers for question {QuestionId}", questionId);
            return new List<Answer>();
        }
    }
}
